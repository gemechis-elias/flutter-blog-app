import '../bloc_event.dart';

class GetTagsEvent extends BlogEvent {
  const GetTagsEvent();
}
