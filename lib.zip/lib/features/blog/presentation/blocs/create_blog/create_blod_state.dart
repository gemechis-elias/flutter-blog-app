import '../bloc_state.dart';

class CreatingBlogState extends BlogState {
  CreatingBlogState();

  @override
  List<Object> get props => [];
}

class CreatedBlogState extends BlogState {
  CreatedBlogState();

  @override
  List<Object> get props => [];
}