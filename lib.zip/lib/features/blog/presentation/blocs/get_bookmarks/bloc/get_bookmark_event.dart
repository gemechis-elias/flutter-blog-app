import '../../bloc_event.dart';

class GetBookmarksEvent extends BlogEvent {
  const GetBookmarksEvent();
}
