import 'package:blog_app/features/user/presentation/blocs/bloc_event.dart';

class GetUserEvent extends UserEvent {
  const GetUserEvent();
}
